-- MySQL dump 10.11
--
-- Host: 127.0.0.1    Database: s-shadow
-- ------------------------------------------------------
-- Server version	5.0.45-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `interp_categories`
--

DROP TABLE IF EXISTS `interp_categories`;
CREATE TABLE `interp_categories` (
  `categoryid` int(11) NOT NULL auto_increment,
  `parentid` int(11) NOT NULL default '0',
  `ordernum` int(11) NOT NULL default '0',
  `actived` tinyint(1) NOT NULL default '1',
  `title` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `keywords` varchar(255) NOT NULL default '',
  `datasize` int(20) NOT NULL default '0',
  `sorting` varchar(16) NOT NULL default 'timedown',
  `watermark` tinyint(1) NOT NULL default '1',
  `watermarkpos` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`categoryid`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_categories`
--

LOCK TABLES `interp_categories` WRITE;
/*!40000 ALTER TABLE `interp_categories` DISABLE KEYS */;
INSERT INTO `interp_categories` VALUES (1,0,1,1,'324','第三方','图片,像片,下载',2048,'odown',1,0),(2,0,2,1,'23','32321321','23',2048,'odown',1,0),(3,0,3,1,'325','5454','5454',2048,'odown',1,0);
/*!40000 ALTER TABLE `interp_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_comments`
--

DROP TABLE IF EXISTS `interp_comments`;
CREATE TABLE `interp_comments` (
  `commentid` int(30) NOT NULL auto_increment,
  `imageid` int(30) NOT NULL default '0',
  `actived` tinyint(1) NOT NULL default '0',
  `username` varchar(64) NOT NULL default '',
  `content` text NOT NULL,
  `created` int(11) NOT NULL default '0',
  PRIMARY KEY  (`commentid`),
  KEY `imageid` (`imageid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_comments`
--

LOCK TABLES `interp_comments` WRITE;
/*!40000 ALTER TABLE `interp_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `interp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_contents`
--

DROP TABLE IF EXISTS `interp_contents`;
CREATE TABLE `interp_contents` (
  `contentid` int(30) NOT NULL auto_increment,
  `username` varchar(64) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `content` mediumtext NOT NULL,
  `keywords` varchar(255) NOT NULL default '',
  `created` int(11) NOT NULL default '0',
  PRIMARY KEY  (`contentid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_contents`
--

LOCK TABLES `interp_contents` WRITE;
/*!40000 ALTER TABLE `interp_contents` DISABLE KEYS */;
INSERT INTO `interp_contents` VALUES (1,'Admin','关于我们','请在后台管理中自定义关于我们的详细内容.发撒范德萨','关于,我们',1265951785),(2,'Admin','联系我们','请在后台管理中自定义联系我们的详细内容.发生地方健康撒娇了看法是减肥看电视啦','联系,我们',1265951785);
/*!40000 ALTER TABLE `interp_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_gimages`
--

DROP TABLE IF EXISTS `interp_gimages`;
CREATE TABLE `interp_gimages` (
  `gimageid` int(30) NOT NULL auto_increment,
  `imageid` int(30) NOT NULL default '0',
  `actived` tinyint(1) NOT NULL default '1',
  `path` varchar(36) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`gimageid`),
  KEY `imageid` (`imageid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_gimages`
--

LOCK TABLES `interp_gimages` WRITE;
/*!40000 ALTER TABLE `interp_gimages` DISABLE KEYS */;
/*!40000 ALTER TABLE `interp_gimages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_images`
--

DROP TABLE IF EXISTS `interp_images`;
CREATE TABLE `interp_images` (
  `imageid` int(30) NOT NULL auto_increment,
  `ordernum` int(30) NOT NULL default '0',
  `categoryid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `username` varchar(64) NOT NULL default '',
  `actived` tinyint(1) NOT NULL default '1',
  `watermark` tinyint(1) NOT NULL default '1',
  `sale` tinyint(1) NOT NULL default '0',
  `recommend` tinyint(1) NOT NULL default '0',
  `usergroupids` text NOT NULL,
  `path` varchar(36) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `price` varchar(36) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `tags` varchar(255) NOT NULL default '',
  `keywords` varchar(255) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `viewcount` int(30) NOT NULL default '0',
  `downloadcount` int(30) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  PRIMARY KEY  (`imageid`),
  KEY `categoryid` (`categoryid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_images`
--

LOCK TABLES `interp_images` WRITE;
/*!40000 ALTER TABLE `interp_images` DISABLE KEYS */;
INSERT INTO `interp_images` VALUES (4,4,1,1,'admin',1,0,0,0,'all','2012_04','3c6b329a70c80ca28d8261a1517bde18.jpg','','蒙蒙','蒙蒙','','蒙蒙','',12,0,1333978518),(3,3,1,1,'admin',1,0,0,0,'all','2012_04','3a484ab3d1beb625deca867d6ae9df77.jpg','浩浩','浩浩','浩浩','','浩浩','',10,0,1333978498);
/*!40000 ALTER TABLE `interp_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_mainsettings`
--

DROP TABLE IF EXISTS `interp_mainsettings`;
CREATE TABLE `interp_mainsettings` (
  `settingid` int(11) NOT NULL auto_increment,
  `varname` varchar(64) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`settingid`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_mainsettings`
--

LOCK TABLES `interp_mainsettings` WRITE;
/*!40000 ALTER TABLE `interp_mainsettings` DISABLE KEYS */;
INSERT INTO `interp_mainsettings` VALUES (1,'adminCookieTimeout','1800'),(2,'siteAllowRegister','0'),(3,'siteAllowGuest','1'),(4,'siteRegisterCheck','Auto'),(5,'siteDefaultLang','Auto'),(6,'siteDefaultTemplate','Blackberry'),(7,'siteNumPerpage','10'),(8,'siteActived','1'),(9,'siteRewrite','0'),(10,'siteTimezone','8'),(11,'siteDateFormat','Y-m-d H:i:s'),(12,'siteOffTitle','网站正在进行数据维护，请稍后光临，谢谢！'),(13,'siteTitle','S-shadow 婚礼 策划 录像 摄影'),(14,'siteCopyright','S-shadow 婚礼 策划 录像 摄影'),(15,'siteKeywords','S-shadow 婚礼 策划 录像 摄影'),(16,'siteMeta','S-shadow 婚礼 策划 录像 摄影'),(17,'siteBeian','www.s-shadow.com'),(18,'siteEmail','lemon.listry@gmail.com'),(19,'siteUseSmtp','0'),(20,'siteSmtpHost','smtp.yoursite.com'),(21,'siteSmtpEmail','yourname@yoursite.com'),(22,'siteSmtpPort','25'),(23,'siteSmtpUser','yourname'),(24,'siteSmtpPassword',''),(25,'siteAppVersion','2.5.1'),(26,'siteAppName','SW50ZXJQaG90bw==');
/*!40000 ALTER TABLE `interp_mainsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_news`
--

DROP TABLE IF EXISTS `interp_news`;
CREATE TABLE `interp_news` (
  `newid` int(30) NOT NULL auto_increment,
  `ordernum` int(30) NOT NULL default '0',
  `actived` tinyint(1) NOT NULL default '0',
  `username` varchar(64) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `content` mediumtext NOT NULL,
  `keywords` varchar(255) NOT NULL default '',
  `viewcount` int(30) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  PRIMARY KEY  (`newid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_news`
--

LOCK TABLES `interp_news` WRITE;
/*!40000 ALTER TABLE `interp_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `interp_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_sessions`
--

DROP TABLE IF EXISTS `interp_sessions`;
CREATE TABLE `interp_sessions` (
  `sessionid` char(64) NOT NULL default '',
  `userid` int(11) default '0',
  `ipaddress` varchar(64) NOT NULL default '',
  `useragent` varchar(255) NOT NULL default '',
  `lastactivity` int(11) NOT NULL default '0',
  `location` tinyint(1) NOT NULL default '0',
  `loggedin` tinyint(1) NOT NULL default '0',
  `admin` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`sessionid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_sessions`
--

LOCK TABLES `interp_sessions` WRITE;
/*!40000 ALTER TABLE `interp_sessions` DISABLE KEYS */;
INSERT INTO `interp_sessions` VALUES ('90c722e8c64688946de0d69ae177a700',1,'183.39.116.136','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.120 Safari/535.2',1333978991,1,1,1);
/*!40000 ALTER TABLE `interp_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_tags`
--

DROP TABLE IF EXISTS `interp_tags`;
CREATE TABLE `interp_tags` (
  `tagid` int(30) NOT NULL auto_increment,
  `tag` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_tags`
--

LOCK TABLES `interp_tags` WRITE;
/*!40000 ALTER TABLE `interp_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `interp_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_usergroups`
--

DROP TABLE IF EXISTS `interp_usergroups`;
CREATE TABLE `interp_usergroups` (
  `groupid` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `allowview` tinyint(1) NOT NULL default '1',
  `allowlogin` tinyint(1) NOT NULL default '0',
  `allowupload` tinyint(1) NOT NULL default '0',
  `allowcomment` tinyint(1) NOT NULL default '0',
  `allowdownload` tinyint(1) NOT NULL default '0',
  `allowdelete` tinyint(1) NOT NULL default '0',
  `allowuploadshow` tinyint(1) NOT NULL default '0',
  `allowcommentshow` tinyint(1) NOT NULL default '0',
  `manage` tinyint(1) NOT NULL default '0',
  `managesetting` tinyint(1) NOT NULL default '0',
  `managecomment` tinyint(1) NOT NULL default '0',
  `managecategory` tinyint(1) NOT NULL default '0',
  `manageuser` tinyint(1) NOT NULL default '0',
  `manageusergroup` tinyint(1) NOT NULL default '0',
  `managenews` tinyint(1) NOT NULL default '0',
  `managenotice` tinyint(1) NOT NULL default '0',
  `managelanguage` tinyint(1) NOT NULL default '0',
  `manageimage` tinyint(1) NOT NULL default '0',
  `managedatabase` tinyint(1) NOT NULL default '0',
  `managetemplate` tinyint(1) NOT NULL default '0',
  `manageupgrade` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_usergroups`
--

LOCK TABLES `interp_usergroups` WRITE;
/*!40000 ALTER TABLE `interp_usergroups` DISABLE KEYS */;
INSERT INTO `interp_usergroups` VALUES (1,'游客',1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0),(2,'禁止登录',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(3,'注册会员',1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0),(4,'系统管理员',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `interp_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_users`
--

DROP TABLE IF EXISTS `interp_users`;
CREATE TABLE `interp_users` (
  `userid` int(11) NOT NULL auto_increment,
  `groupid` int(11) NOT NULL,
  `activated` tinyint(1) NOT NULL default '0',
  `username` varchar(64) NOT NULL default '',
  `password` varchar(64) NOT NULL default '',
  `verifycode` varchar(8) NOT NULL default '',
  `email` varchar(128) NOT NULL default '',
  `joindate` int(11) NOT NULL default '0',
  `lastactivity` int(11) NOT NULL default '0',
  `userfullname` varchar(128) NOT NULL default '',
  `usercompany` varchar(225) NOT NULL default '',
  `useraddress` varchar(255) NOT NULL default '',
  `userpostcode` varchar(32) NOT NULL default '',
  `usertel` varchar(255) NOT NULL default '',
  `userfax` varchar(255) NOT NULL default '',
  `useronline` varchar(255) NOT NULL default '',
  `userwebsite` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`userid`),
  KEY `groupid` (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_users`
--

LOCK TABLES `interp_users` WRITE;
/*!40000 ALTER TABLE `interp_users` DISABLE KEYS */;
INSERT INTO `interp_users` VALUES (1,4,1,'admin','6fe552fafc0cac162647bc1098e3264b','','lemon.listry@gmail.com',1333977520,1333977563,'','','','','','','','');
/*!40000 ALTER TABLE `interp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interp_vvc`
--

DROP TABLE IF EXISTS `interp_vvc`;
CREATE TABLE `interp_vvc` (
  `vvcid` int(30) NOT NULL auto_increment,
  `code` varchar(9) NOT NULL default '',
  `date` int(11) NOT NULL default '0',
  PRIMARY KEY  (`vvcid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interp_vvc`
--

LOCK TABLES `interp_vvc` WRITE;
/*!40000 ALTER TABLE `interp_vvc` DISABLE KEYS */;
INSERT INTO `interp_vvc` VALUES (1,'POKTI',1333978006),(2,'XORMR',1333978012),(3,'',1334002853),(4,'',1334049569),(5,'',1334061856),(6,'',1334128487);
/*!40000 ALTER TABLE `interp_vvc` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-04-13 16:37:12
